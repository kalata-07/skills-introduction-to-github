package automation.qa;

import java.util.Scanner;

public class My_First {
    public static void main(String[] args) {
        System.out.println("Hello Java!");

        Scanner scanner = new Scanner(System.in);
        String firstName=scanner.next();
        System.out.println("Your name is: "+ firstName);

        System.out.println("Age: ");
        int age = scanner.nextInt();
        System.out.println("Your age is: "+age);
    }
}
